"""
CS6168 Project 2: PakWheels Automotive Advertising Budget Optimizer
------------------------------------------------------------------
Project 1 data is the unchanged foundation:
  video_id, comment_text, likes, published_at, processed_comment, sentiment

Project 2 advertising fields are simulated (not real ad-platform records).
Each source comment is retained and linked to a campaign based on its
original PakWheels video_id. The simulation creates advertising observations
for Facebook, Instagram, Google, TikTok and YouTube, using car-interest/
sentiment context from Project 1.

Run:
  python pakwheels_advertising_optimizer.py
Optional environment variables:
  PAKWHEELS_SOURCE_CSV, PAKWHEELS_OUTPUT_DIR
  PAKWHEELS_SCALES=10000,100000,1000000,10000000
  PAKWHEELS_CHUNK_SIZE=50000
  PAKWHEELS_RUN_SPARK=1
"""

from pathlib import Path
import os, time, json, math
import numpy as np
import pandas as pd

SOURCE_DEFAULT = Path(__file__).with_name("Pakwheels Final Sentiment Results.csv")
SOURCE_CSV = Path(os.getenv("PAKWHEELS_SOURCE_CSV", str(SOURCE_DEFAULT)))
OUTPUT_DIR = Path(os.getenv("PAKWHEELS_OUTPUT_DIR", str(Path(__file__).with_name("pakwheels_project2_outputs"))))
SCALES = [int(x.strip()) for x in os.getenv("PAKWHEELS_SCALES", "10000,100000,1000000,10000000").split(",") if x.strip()]
CHUNK_SIZE = int(os.getenv("PAKWHEELS_CHUNK_SIZE", "50000"))
RUN_SPARK = os.getenv("PAKWHEELS_RUN_SPARK", "0") == "1"
SEED = 42

SOURCE_COLUMNS = ["video_id", "comment_text", "likes", "published_at", "processed_comment", "sentiment"]
PLATFORMS = ["Facebook", "Instagram", "Google", "TikTok", "YouTube"]
PLATFORM_WEIGHTS = np.array([0.22, 0.22, 0.20, 0.16, 0.20])

def load_project1_data():
    if not SOURCE_CSV.exists():
        raise FileNotFoundError(
            f"Source CSV not found: {SOURCE_CSV}\n"
            "Place 'Pakwheels Final Sentiment Results.csv' beside this script."
        )
    df = pd.read_csv(SOURCE_CSV)
    missing = [c for c in SOURCE_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Project 1 source is missing required columns: {missing}")
    # Preserve source values and columns. No overwriting or re-cleaning.
    source = df[SOURCE_COLUMNS].copy()
    source["source_project"] = "Project 1 - PakWheels YouTube Sentiment Analysis"
    source["campaign"] = source["video_id"].astype(str).map(lambda x: f"PakWheels_Car_Review_{x}")
    return source

def simulate_advertising_records(source, n_rows, seed=SEED):
    """Create simulated advertising rows while retaining a link to each source comment."""
    rng = np.random.default_rng(seed + n_rows)
    idx = rng.integers(0, len(source), size=n_rows)
    s = source.iloc[idx].reset_index(drop=True)
    out = s.copy()
    out["date"] = pd.to_datetime(out["published_at"], errors="coerce", utc=True).dt.strftime("%Y-%m-%d")
    # The ad-platform observations are synthetic; sentiment is used only as audience-context.
    out["platform"] = rng.choice(PLATFORMS, size=n_rows, p=PLATFORM_WEIGHTS)
    sentiment = out["sentiment"].fillna("Unclassified").astype(str).str.lower()
    sentiment_factor = np.select(
        [sentiment.eq("positive"), sentiment.eq("negative"), sentiment.eq("neutral")],
        [1.15, 0.82, 1.0], default=0.90
    )
    impressions = rng.integers(500, 20000, size=n_rows)
    ctr_base = rng.uniform(0.008, 0.055, size=n_rows) * sentiment_factor
    clicks = np.maximum(0, np.minimum(impressions, np.rint(impressions * ctr_base))).astype(int)
    cpc = rng.uniform(8.0, 65.0, size=n_rows)
    spend = np.round(clicks * cpc, 2)
    cvr = rng.uniform(0.008, 0.12, size=n_rows) * np.where(sentiment.eq("positive"), 1.12, 1.0)
    conversions = np.minimum(clicks, np.rint(clicks * cvr)).astype(int)
    order_value = rng.uniform(25000, 180000, size=n_rows)
    revenue = np.round(conversions * order_value, 2)

    out["impressions"] = impressions
    out["clicks"] = clicks
    out["spend"] = spend
    out["conversions"] = conversions
    out["revenue"] = revenue
    out["age"] = rng.choice(["18-24", "25-34", "35-44", "45-54", "55+"], size=n_rows,
                            p=[0.16, 0.34, 0.25, 0.16, 0.09])
    out["gender"] = rng.choice(["Female", "Male", "Unknown"], size=n_rows, p=[0.24, 0.70, 0.06])
    out["city"] = rng.choice(
        ["Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad", "Peshawar", "Multan"],
        size=n_rows, p=[0.24, 0.25, 0.15, 0.12, 0.09, 0.08, 0.07]
    )
    out["device"] = rng.choice(["Mobile", "Desktop", "Tablet"], size=n_rows, p=[0.76, 0.21, 0.03])
    out["simulation_flag"] = "SIMULATED_AD_METRICS"
    return out

def calculate_kpis(df, group_cols):
    g = df.groupby(group_cols, dropna=False).agg(
        records=("campaign", "size"),
        impressions=("impressions", "sum"),
        clicks=("clicks", "sum"),
        spend=("spend", "sum"),
        conversions=("conversions", "sum"),
        revenue=("revenue", "sum")
    ).reset_index()
    g["CTR_pct"] = np.where(g.impressions > 0, g.clicks / g.impressions * 100, 0)
    g["CPC"] = np.where(g.clicks > 0, g.spend / g.clicks, 0)
    g["CPA"] = np.where(g.conversions > 0, g.spend / g.conversions, 0)
    g["conversion_rate_pct"] = np.where(g.clicks > 0, g.conversions / g.clicks * 100, 0)
    g["ROAS"] = np.where(g.spend > 0, g.revenue / g.spend, 0)
    return g

def mapreduce_style_aggregate(df, group_col="platform"):
    """Local MapReduce-style demonstration: map partial sums, then reduce them."""
    keys = ["impressions", "clicks", "spend", "conversions", "revenue"]
    partials = []
    for start in range(0, len(df), CHUNK_SIZE):
        chunk = df.iloc[start:start + CHUNK_SIZE]
        partials.append(chunk.groupby(group_col)[keys].sum())
    combined = pd.concat(partials).groupby(level=0).sum().reset_index()
    combined["CTR_pct"] = np.where(combined.impressions > 0, combined.clicks / combined.impressions * 100, 0)
    combined["CPC"] = np.where(combined.clicks > 0, combined.spend / combined.clicks, 0)
    combined["CPA"] = np.where(combined.conversions > 0, combined.spend / combined.conversions, 0)
    combined["conversion_rate_pct"] = np.where(combined.clicks > 0, combined.conversions / combined.clicks * 100, 0)
    combined["ROAS"] = np.where(combined.spend > 0, combined.revenue / combined.spend, 0)
    return combined

def recommend_budget(platform_metrics, total_budget=1_000_000):
    """Score platforms using simulated ROAS and conversion volume; allocate all budget."""
    m = platform_metrics.copy()
    m["score"] = m["ROAS"].clip(lower=0) * np.sqrt(m["conversions"] + 1)
    if m["score"].sum() <= 0:
        m["budget_share_pct"] = 100 / len(m)
    else:
        m["budget_share_pct"] = m["score"] / m["score"].sum() * 100
    m["recommended_budget_rs"] = m["budget_share_pct"] / 100 * total_budget
    return m.sort_values("recommended_budget_rs", ascending=False)

def save_scale_run(source, n_rows):
    start = time.perf_counter()
    df = simulate_advertising_records(source, n_rows)
    generation_seconds = time.perf_counter() - start
    data_path = OUTPUT_DIR / f"pakwheels_automotive_ads_{n_rows}.csv"
    df.to_csv(data_path, index=False)

    start = time.perf_counter()
    pandas_metrics = calculate_kpis(df, ["platform"])
    pandas_seconds = time.perf_counter() - start

    start = time.perf_counter()
    mr_metrics = mapreduce_style_aggregate(df)
    mapreduce_seconds = time.perf_counter() - start

    # Verify equivalent aggregate totals between Pandas and MapReduce-style results.
    check = pandas_metrics.set_index("platform")[["impressions", "clicks", "spend", "conversions", "revenue"]].sort_index()
    check2 = mr_metrics.set_index("platform")[["impressions", "clicks", "spend", "conversions", "revenue"]].sort_index()
    pd.testing.assert_frame_equal(check, check2, check_exact=False, rtol=1e-9, atol=1e-6)

    campaign_metrics = calculate_kpis(df, ["campaign", "video_id"])
    budget = recommend_budget(pandas_metrics)
    pandas_metrics.to_csv(OUTPUT_DIR / f"platform_kpis_{n_rows}.csv", index=False)
    campaign_metrics.to_csv(OUTPUT_DIR / f"campaign_kpis_{n_rows}.csv", index=False)
    budget.to_csv(OUTPUT_DIR / f"budget_recommendation_{n_rows}.csv", index=False)

    return {
        "records": n_rows,
        "generation_seconds": round(generation_seconds, 4),
        "pandas_seconds": round(pandas_seconds, 4),
        "mapreduce_style_seconds": round(mapreduce_seconds, 4),
        "spark_status": "Not run (set PAKWHEELS_RUN_SPARK=1 in a Spark-enabled environment)"
    }, df, pandas_metrics, budget

def try_spark(df):
    try:
        from pyspark.sql import SparkSession, functions as F
        spark = SparkSession.builder.appName("PakWheelsAutomotiveBudgetOptimizer").getOrCreate()
        sdf = spark.createDataFrame(df[["platform","impressions","clicks","spend","conversions","revenue"]])
        result = sdf.groupBy("platform").agg(
            F.sum("impressions").alias("impressions"), F.sum("clicks").alias("clicks"),
            F.sum("spend").alias("spend"), F.sum("conversions").alias("conversions"),
            F.sum("revenue").alias("revenue"))
        result = result.withColumn("CTR_pct", F.when(F.col("impressions")>0, F.col("clicks")/F.col("impressions")*100).otherwise(0))
        result = result.withColumn("CPC", F.when(F.col("clicks")>0, F.col("spend")/F.col("clicks")).otherwise(0))
        result = result.withColumn("CPA", F.when(F.col("conversions")>0, F.col("spend")/F.col("conversions")).otherwise(0))
        result = result.withColumn("conversion_rate_pct", F.when(F.col("clicks")>0, F.col("conversions")/F.col("clicks")*100).otherwise(0))
        result = result.withColumn("ROAS", F.when(F.col("spend")>0, F.col("revenue")/F.col("spend")).otherwise(0))
        result.toPandas().to_csv(OUTPUT_DIR / "spark_platform_kpis.csv", index=False)
        spark.stop()
        return "Completed"
    except Exception as exc:
        return f"Skipped: {type(exc).__name__}: {exc}"

def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    source = load_project1_data()
    source.to_csv(OUTPUT_DIR / "project1_source_preserved.csv", index=False)
    summary = {
        "project1_source_rows": int(len(source)),
        "project1_source_columns": SOURCE_COLUMNS,
        "source_columns_preserved": True,
        "advertising_metrics_are_simulated": True,
        "scales_requested": SCALES
    }
    run_results = []
    for n in SCALES:
        result, df, metrics, budget = save_scale_run(source, n)
        run_results.append(result)
        if n == SCALES[0]:
            # Keep a small preview and charts for the smallest run.
            df.head(1000).to_csv(OUTPUT_DIR / "automotive_ads_preview_1000.csv", index=False)
            metrics.to_csv(OUTPUT_DIR / "platform_kpis_preview.csv", index=False)
            budget.to_csv(OUTPUT_DIR / "budget_recommendation_preview.csv", index=False)
    if RUN_SPARK:
        sample = simulate_advertising_records(source, min(SCALES[-1], 100000))
        summary["spark_status"] = try_spark(sample)
    else:
        summary["spark_status"] = "Not run; optional Spark execution is disabled."
    pd.DataFrame(run_results).to_csv(OUTPUT_DIR / "processing_comparison.csv", index=False)
    with open(OUTPUT_DIR / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump({**summary, "runs": run_results}, f, indent=2)
    print(json.dumps({**summary, "runs": run_results}, indent=2))
    print(f"\nOutputs saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
